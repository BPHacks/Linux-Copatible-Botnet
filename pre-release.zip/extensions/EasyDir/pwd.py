if isclient == False:
    response = receive(client)
    print(response.decode('utf-8'))
else:
    current_path = os.getcwd()
    send(server, current_path.encode('utf-8'))