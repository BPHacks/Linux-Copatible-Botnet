if len(cmd.split()) == 2 and cmd.split()[0].lower() == 'show' and cmd.split()[1].lower() == 'list':
    if len(address) > 0:
        print(Fore.LIGHTBLUE_EX + 'connected clients:' + Fore.RESET)
    else:
        print(Fore.LIGHTBLUE_EX + 'You have no connected clients at the moment.' + Fore.RESET)
    for addrn in range(len(address)):
        addr = address[addrn]
        ip, port = addr
        ip = str(ip)
        port = str(port)
        print(Fore.LIGHTYELLOW_EX + str(addrn + 1) + '. ' + Fore.LIGHTBLUE_EX + 'ip: ' + str(ip) + ' port: ' + str(port) + Fore.RESET)

    print(Fore.LIGHTBLUE_EX + '---------------------' + Fore.RESET)
elif cmd.split()[0].lower() == 'list':
    if len(address) > 0:
        print(Fore.LIGHTBLUE_EX + 'connected clients:' + Fore.RESET)
    else:
        print(Fore.LIGHTBLUE_EX + 'You have no connected clients at the moment.' + Fore.RESET)
    for addrn in range(len(address)):
        addr = address[addrn]
        ip, port = addr
        ip = str(ip)
        port = str(port)
        print(Fore.LIGHTYELLOW_EX + str(addrn + 1) + '. ' + Fore.LIGHTBLUE_EX + 'ip: ' + str(ip) + ' port: ' + str(port) + Fore.RESET)

    print(Fore.LIGHTBLUE_EX + '---------------------' + Fore.RESET)
else:
    pass