import platform
import os

if platform.system().lower() == 'windows':
    os.system('cls')
else:
    os.system('clear')